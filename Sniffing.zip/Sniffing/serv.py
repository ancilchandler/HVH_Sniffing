from flask import Flask, render_template, redirect, url_for, request, flash, make_response
import base64

app = Flask(__name__)
app.secret_key = "some_secret_key"  # Change this to a more secure key

# In-memory 'database' using a dictionary
users = {}
users["testuser"] = "testpassword"
users["admin"] = "SuperSeCurePassphrase999"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if users.get(username) == password:
            response = make_response(redirect(url_for('protected')))
            cookie_bytes = username.encode("ascii")
            base64_bytes = base64.b64encode(cookie_bytes)
            base64_string = base64_bytes.decode("ascii")
            response.set_cookie('user_id', base64_string, max_age=3600)  # Set a secure cookie
            return response
        flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    response = make_response(redirect(url_for('login')))
    response.delete_cookie('user_id')  # Delete the user_id cookie
    return response

@app.route('/protected')
def protected():
    user_id = request.cookies.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    base64_bytes = user_id.encode("ascii")
    ret_string_bytes = base64.b64decode(base64_bytes)
    new_string = ret_string_bytes.decode("ascii")
    print(new_string)
    return f"Hello {new_string}! Welcome to the protected page."

@app.route('/')
def home():
    return render_template('home.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
